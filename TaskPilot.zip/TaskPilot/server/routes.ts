import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema, updateTaskSchema } from "@shared/schema";
import { z } from "zod";

// Mock user session for demo purposes
interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    picture?: string;
  };
}

// Middleware to simulate authentication
const authenticate = async (req: AuthenticatedRequest, res: Response, next: any) => {
  // For demo purposes, create a mock user session
  // In production, this would validate actual OAuth tokens
  const mockUserId = "demo-user-1";
  let user = await storage.getUser(mockUserId);
  
  if (!user) {
    // Create mock user if it doesn't exist
    user = await storage.createUser({
      email: "demo@example.com",
      name: "Demo User",
      picture: null,
      provider: "google",
      providerId: "google-123"
    });
  }
  
  req.user = {
    id: user.id,
    email: user.email,
    name: user.name,
    picture: user.picture
  };
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Auth routes
  app.post("/api/auth/google", async (req: Request, res: Response) => {
    try {
      // Mock Google OAuth - in production this would validate the Google token
      const { token } = req.body;
      
      // Mock user data that would come from Google
      const mockUserData = {
        email: "demo@example.com",
        name: "Demo User",
        picture: undefined,
        provider: "google",
        providerId: "google-123"
      };

      let user = await storage.getUserByEmail(mockUserData.email);
      if (!user) {
        user = await storage.createUser(mockUserData);
      }

      res.json({ user, success: true });
    } catch (error) {
      res.status(400).json({ message: "Authentication failed", success: false });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    res.json({ success: true });
  });

  app.get("/api/auth/me", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json(user);
  });

  // Task routes
  app.get("/api/tasks", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const tasks = await storage.getTasks(req.user.id);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      console.log("Creating task with data:", req.body);
      
      const taskData = insertTaskSchema.parse({
        ...req.body,
        userId: req.user.id,
        dueDate: req.body.dueDate ? new Date(req.body.dueDate) : null
      });

      console.log("Parsed task data:", taskData);

      const task = await storage.createTask(taskData);
      res.json(task);
    } catch (error) {
      console.error("Task creation error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.put("/api/tasks/:id", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const { id } = req.params;
      const updates = updateTaskSchema.parse(req.body);

      const task = await storage.updateTask(id, req.user.id, updates);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", authenticate, async (req: AuthenticatedRequest, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const { id } = req.params;
      const deleted = await storage.deleteTask(id, req.user.id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
