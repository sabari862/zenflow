# ZenFlow - Mindful Task Management App

## Overview

ZenFlow is a mindful mobile-first Progressive Web Application (PWA) built with React, TypeScript, and Express. The app promotes balance and simplicity in productivity management, featuring a unique custom logo design and peaceful gradient aesthetic. ZenFlow delivers a native mobile experience through web technologies with full CRUD operations, social authentication, and zen-inspired UX features. Users can find balance in productivity with features like priority levels, due dates, filtering, search, pull-to-refresh, and smooth animations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety
- **Styling**: Tailwind CSS with custom design system and CSS variables
- **UI Components**: Radix UI primitives wrapped in custom components following shadcn/ui patterns
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Animations**: Framer Motion for smooth transitions and micro-interactions
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Validation**: Zod for runtime type checking and API validation
- **Session Storage**: In-memory storage for development (designed for database session storage in production)

### Authentication System
- **Strategy**: Social OAuth authentication (Google, Apple, Facebook)
- **Implementation**: Mock authentication for development with extensible architecture for production OAuth providers
- **Session Management**: Express sessions with user context middleware

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Design**: Two main entities - Users and Tasks with proper foreign key relationships
- **Migration System**: Drizzle Kit for database schema management

### Mobile-First Design
- **Responsive Layout**: Mobile-first approach with progressive enhancement for desktop
- **Touch Interactions**: Swipe gestures, pull-to-refresh, and touch-optimized UI components
- **PWA Features**: Web app manifest for installable mobile experience
- **Performance**: Optimized for mobile with lazy loading and efficient re-renders

### Component Architecture
- **Design System**: Consistent component library with variant-based styling
- **Reusability**: Composable UI components with proper prop interfaces
- **Accessibility**: ARIA compliance and keyboard navigation support
- **Performance**: Memoized components and efficient re-rendering patterns

## External Dependencies

### Core Infrastructure
- **Database**: Neon Database (PostgreSQL) - serverless database hosting
- **ORM**: Drizzle ORM - type-safe database queries and migrations
- **Validation**: Zod - runtime schema validation for API endpoints and forms

### UI and Styling
- **Component Library**: Radix UI - accessible, unstyled component primitives
- **Styling Framework**: Tailwind CSS - utility-first CSS framework
- **Icons**: Lucide React - consistent icon library
- **Animations**: Framer Motion - declarative animations and gestures

### Development Tools
- **Build System**: Vite - fast build tool and development server
- **TypeScript**: Full type safety across frontend and backend
- **Code Quality**: ESLint and Prettier for consistent code formatting

### Authentication Providers
- **Google OAuth**: For social authentication (mock implementation included)
- **Apple Sign-In**: Planned integration for iOS users
- **Facebook Login**: Planned integration for social login options

### Utilities
- **Date Handling**: date-fns for date manipulation and formatting
- **HTTP Client**: Native fetch with TanStack Query for caching and synchronization
- **Form Management**: React Hook Form for efficient form handling
- **Routing**: Wouter for lightweight client-side navigation

### Development and Deployment
- **Package Manager**: npm with lock file for consistent dependencies
- **Environment**: Node.js ES modules with TypeScript compilation
- **Asset Handling**: Vite for static asset optimization and bundling
- **Database Migrations**: Drizzle Kit for schema versioning and deployment