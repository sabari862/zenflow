// Mock Google OAuth implementation
// In a real application, this would use the Google OAuth SDK

export interface GoogleAuthResponse {
  token: string;
  user: {
    email: string;
    name: string;
    picture?: string;
  };
}

export class AuthError extends Error {
  constructor(message: string, public code?: string) {
    super(message);
    this.name = "AuthError";
  }
}

export async function signInWithGoogle(): Promise<GoogleAuthResponse> {
  // Simulate Google OAuth flow
  return new Promise((resolve, reject) => {
    // Mock successful authentication
    setTimeout(() => {
      const mockUser = {
        email: "demo@example.com",
        name: "Demo User",
        picture: undefined,
      };

      resolve({
        token: "mock-google-token-" + Date.now(),
        user: mockUser,
      });
    }, 1000);
  });
}

export async function signInWithApple(): Promise<GoogleAuthResponse> {
  throw new AuthError("Apple Sign-In not implemented", "NOT_IMPLEMENTED");
}

export async function signInWithFacebook(): Promise<GoogleAuthResponse> {
  throw new AuthError("Facebook Sign-In not implemented", "NOT_IMPLEMENTED");
}

// Initialize authentication state from localStorage
export function getStoredAuthToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("auth_token");
}

export function setStoredAuthToken(token: string): void {
  if (typeof window === "undefined") return;
  localStorage.setItem("auth_token", token);
}

export function removeStoredAuthToken(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem("auth_token");
}
