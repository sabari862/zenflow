import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Bell, Settings, Plus, Calendar, AlertTriangle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { FloatingActionButton } from "@/components/ui/floating-action-button";
import { TaskCard } from "@/components/task-card";
import { TaskModal } from "@/components/task-modal";
import { DeleteConfirmation } from "@/components/delete-confirmation";
import { PullToRefresh } from "@/components/pull-to-refresh";
import { useTasks } from "@/hooks/use-tasks";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Task } from "@shared/schema";

type FilterType = "all" | "pending" | "completed" | "today" | "overdue";

export default function Dashboard() {
  const { user } = useAuth();
  const { tasks, isLoading, createTask, updateTask, deleteTask, refreshTasks } = useTasks();
  const { toast } = useToast();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<FilterType>("all");
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deleteTaskId, setDeleteTaskId] = useState<string | null>(null);

  // Filter tasks based on active filter and search query
  const filteredTasks = tasks?.filter((task) => {
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (
        !task.title.toLowerCase().includes(query) &&
        !task.description?.toLowerCase().includes(query)
      ) {
        return false;
      }
    }

    // Status filter
    switch (activeFilter) {
      case "pending":
        return task.status === "pending";
      case "completed":
        return task.status === "completed";
      case "today":
        if (!task.dueDate) return false;
        const today = new Date();
        const dueDate = new Date(task.dueDate);
        return (
          dueDate.toDateString() === today.toDateString() &&
          task.status === "pending"
        );
      case "overdue":
        if (!task.dueDate) return false;
        const now = new Date();
        const due = new Date(task.dueDate);
        return due < now && task.status === "pending";
      default:
        return true;
    }
  }) || [];

  // Statistics
  const totalTasks = tasks?.length || 0;
  const completedTasks = tasks?.filter(t => t.status === "completed").length || 0;
  const pendingTasks = totalTasks - completedTasks;

  const handleCreateTask = async (taskData: any) => {
    try {
      await createTask.mutateAsync(taskData);
      setIsTaskModalOpen(false);
      toast({
        title: "Task Created",
        description: "Your task has been added successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create task. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUpdateTask = async (taskData: any) => {
    if (!editingTask) return;
    
    try {
      await updateTask.mutateAsync({ id: editingTask.id, updates: taskData });
      setIsTaskModalOpen(false);
      setEditingTask(null);
      toast({
        title: "Task Updated",
        description: "Your task has been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleToggleComplete = async (task: Task) => {
    try {
      const newStatus = task.status === "completed" ? "pending" : "completed";
      await updateTask.mutateAsync({ 
        id: task.id, 
        updates: { status: newStatus } 
      });
      toast({
        title: newStatus === "completed" ? "Task Completed!" : "Task Reopened",
        description: newStatus === "completed" 
          ? "Great job completing your task!" 
          : "Task marked as pending.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task status.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteTask = async () => {
    if (!deleteTaskId) return;
    
    try {
      await deleteTask.mutateAsync(deleteTaskId);
      setDeleteTaskId(null);
      toast({
        title: "Task Deleted",
        description: "Your task has been deleted successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete task. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsTaskModalOpen(true);
  };

  const filterTabs = [
    { key: "all", label: "All Tasks", count: totalTasks },
    { key: "pending", label: "Pending", count: pendingTasks },
    { key: "completed", label: "Completed", count: completedTasks },
    { key: "today", label: "Due Today", count: filteredTasks.filter(t => activeFilter === "today").length },
    { key: "overdue", label: "Overdue", count: filteredTasks.filter(t => activeFilter === "overdue").length },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <PullToRefresh onRefresh={() => refreshTasks()}>
        {/* Header with Search */}
        <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40 safe-area-top">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-sm" data-testid="text-user-initials">
                    {user?.name?.split(' ').map(n => n[0]).join('') || 'U'}
                  </span>
                </div>
                <div>
                  <h2 className="font-semibold text-gray-800" data-testid="text-user-name">
                    {user?.name || 'User'}
                  </h2>
                  <p className="text-sm text-gray-500" data-testid="text-task-count">
                    {pendingTasks} tasks pending
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-2 text-gray-500 hover:text-purple-500 hover:bg-purple-50 rounded-xl"
                  data-testid="button-notifications"
                >
                  <Bell className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-2 text-gray-500 hover:text-purple-500 hover:bg-purple-50 rounded-xl"
                  data-testid="button-settings"
                >
                  <Settings className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search tasks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search"
                className="w-full pl-12 pr-4 py-3 bg-gray-100 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
          </div>
        </header>

        {/* Filter Tabs */}
        <div className="bg-white border-b border-gray-200">
          <div className="px-6 py-4">
            <div className="flex space-x-2 overflow-x-auto scrollbar-hide">
              {filterTabs.map((tab) => (
                <Button
                  key={tab.key}
                  onClick={() => setActiveFilter(tab.key as FilterType)}
                  data-testid={`button-filter-${tab.key}`}
                  className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition-all ${
                    activeFilter === tab.key
                      ? "bg-purple-500 text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                  variant="ghost"
                >
                  {tab.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <main className="flex-1 px-6 py-6 pb-32 min-h-screen">
          {/* Task Statistics Cards */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 p-4 rounded-2xl text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Total Tasks</p>
                  <p className="text-2xl font-bold" data-testid="text-total-tasks">
                    {totalTasks}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-purple-200" />
              </div>
            </Card>
            <Card className="bg-gradient-to-r from-green-500 to-green-600 p-4 rounded-2xl text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">Completed</p>
                  <p className="text-2xl font-bold" data-testid="text-completed-tasks">
                    {completedTasks}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-200" />
              </div>
            </Card>
          </div>

          {/* Task List */}
          <div data-testid="container-task-list">
            {isLoading ? (
              <div className="space-y-4" data-testid="loading-tasks">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse bg-white rounded-2xl p-4 shadow-sm">
                    <div className="flex items-center space-x-4">
                      <div className="w-5 h-5 bg-gray-200 rounded"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : filteredTasks.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-16"
                data-testid="empty-state"
              >
                <div className="w-32 h-32 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Calendar className="h-16 w-16 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-gray-700 mb-2">
                  {searchQuery || activeFilter !== "all" ? "No tasks found" : "No tasks yet"}
                </h3>
                <p className="text-gray-500 mb-8">
                  {searchQuery || activeFilter !== "all" 
                    ? "Try adjusting your search or filter criteria" 
                    : "Start by adding your first task to get organized!"}
                </p>
                {!searchQuery && activeFilter === "all" && (
                  <Button
                    onClick={() => setIsTaskModalOpen(true)}
                    data-testid="button-add-first-task"
                    className="bg-purple-500 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-purple-600"
                  >
                    <Plus className="mr-2 h-5 w-5" />
                    Add Your First Task
                  </Button>
                )}
              </motion.div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence>
                  {filteredTasks.map((task, index) => (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -300 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <TaskCard
                        task={task}
                        onToggleComplete={() => handleToggleComplete(task)}
                        onEdit={() => handleEditTask(task)}
                        onDelete={() => setDeleteTaskId(task.id)}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </main>

        {/* Floating Action Button */}
        <FloatingActionButton
          onClick={() => setIsTaskModalOpen(true)}
          data-testid="button-add-task"
        >
          <Plus className="h-6 w-6" />
        </FloatingActionButton>

        {/* Task Modal */}
        <TaskModal
          isOpen={isTaskModalOpen}
          onClose={() => {
            setIsTaskModalOpen(false);
            setEditingTask(null);
          }}
          onSubmit={editingTask ? handleUpdateTask : handleCreateTask}
          initialData={editingTask}
          isEditing={!!editingTask}
        />

        {/* Delete Confirmation */}
        <DeleteConfirmation
          isOpen={!!deleteTaskId}
          onClose={() => setDeleteTaskId(null)}
          onConfirm={handleDeleteTask}
        />

        {/* Bottom Safe Area */}
        <div className="safe-area-bottom bg-white"></div>
      </PullToRefresh>
    </div>
  );
}
