import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { CheckCheck, AlertCircle } from "lucide-react";
import { FaGoogle, FaApple, FaFacebook } from "react-icons/fa";

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { login } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      await login("google", "mock-token");
      setLocation("/dashboard");
      toast({
        title: "Welcome!",
        description: "Successfully signed in with Google.",
      });
    } catch (err) {
      const errorMessage = "Authentication failed. Please try again.";
      setError(errorMessage);
      toast({
        title: "Login Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    toast({
      title: "Coming Soon",
      description: "Apple Sign-In will be available soon.",
    });
  };

  const handleFacebookLogin = async () => {
    toast({
      title: "Coming Soon", 
      description: "Facebook Sign-In will be available soon.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        {/* App Logo & Branding */}
        <div className="text-center mb-12">
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl"
          >
            <svg 
              width="32" 
              height="32" 
              viewBox="0 0 32 32" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className="text-purple-500"
            >
              <circle cx="16" cy="16" r="14" stroke="currentColor" strokeWidth="2" fill="none"/>
              <path d="M8 16 C8 16, 12 20, 16 16 C16 16, 20 8, 24 12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
              <circle cx="16" cy="16" r="3" fill="currentColor"/>
            </svg>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-4xl font-bold text-white mb-3"
          >
ZenFlow
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-purple-100 text-lg"
          >
            Find balance in productivity, flow in simplicity
          </motion.p>
        </div>

        {/* Social Login Options */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="space-y-4"
        >
          <Button
            onClick={handleGoogleLogin}
            disabled={isLoading}
            data-testid="button-google-login"
            className="w-full bg-white text-gray-700 rounded-2xl py-6 px-6 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 disabled:opacity-50"
            variant="outline"
          >
            <FaGoogle className="text-xl text-red-500" />
            <span className="font-semibold">
              {isLoading ? "Signing in..." : "Continue with Google"}
            </span>
          </Button>

          <Button
            onClick={handleAppleLogin}
            data-testid="button-apple-login"
            className="w-full bg-gray-900 text-white rounded-2xl py-6 px-6 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <FaApple className="text-xl" />
            <span className="font-semibold">Continue with Apple</span>
          </Button>

          <Button
            onClick={handleFacebookLogin}
            data-testid="button-facebook-login"
            className="w-full bg-blue-600 text-white rounded-2xl py-6 px-6 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <FaFacebook className="text-xl" />
            <span className="font-semibold">Continue with Facebook</span>
          </Button>
        </motion.div>

        {/* Error State Display */}
        {error && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-6"
          >
            <Card className="bg-red-100 border border-red-300 text-red-700 px-4 py-3 rounded-xl">
              <div className="flex items-center space-x-2">
                <AlertCircle className="h-5 w-5" />
                <span data-testid="text-error-message">{error}</span>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Terms & Privacy */}
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-center text-purple-100 text-sm mt-8 leading-relaxed"
        >
          By continuing, you agree to our{" "}
          <a href="#" className="underline font-medium">
            Terms of Service
          </a>{" "}
          and{" "}
          <a href="#" className="underline font-medium">
            Privacy Policy
          </a>
        </motion.p>
      </motion.div>
    </div>
  );
}
