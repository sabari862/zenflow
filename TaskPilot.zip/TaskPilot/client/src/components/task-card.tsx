import { motion } from "framer-motion";
import { Edit, Trash2, Calendar, AlertTriangle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Task } from "@shared/schema";
import { format, isToday, isPast, isTomorrow } from "date-fns";

interface TaskCardProps {
  task: Task;
  onToggleComplete: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export function TaskCard({ task, onToggleComplete, onEdit, onDelete }: TaskCardProps) {
  const isCompleted = task.status === "completed";
  const dueDate = task.dueDate ? new Date(task.dueDate) : null;
  const isOverdue = dueDate && isPast(dueDate) && !isCompleted;
  const isDueToday = dueDate && isToday(dueDate);
  const isDueTomorrow = dueDate && isTomorrow(dueDate);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500";
      case "medium":
        return "bg-yellow-500";
      case "low":
        return "bg-green-500";
      default:
        return "bg-gray-300";
    }
  };

  const formatDueDate = () => {
    if (!dueDate) return null;
    
    if (isDueToday) return "Today";
    if (isDueTomorrow) return "Tomorrow";
    if (isOverdue) return `${Math.ceil((Date.now() - dueDate.getTime()) / (1000 * 60 * 60 * 24))} days overdue`;
    return format(dueDate, "MMM d");
  };

  const getDateColor = () => {
    if (isOverdue) return "text-red-600";
    if (isDueToday) return "text-yellow-600";
    return "text-gray-600";
  };

  return (
    <motion.div
      layout
      data-testid={`task-card-${task.id}`}
      className={cn(
        "bg-white rounded-2xl p-4 shadow-sm border transition-all duration-300 hover:shadow-md",
        isOverdue && !isCompleted && "bg-red-50 border-red-200",
        isCompleted && "opacity-75"
      )}
    >
      <div className="flex items-start space-x-4">
        {/* Task Checkbox */}
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={onToggleComplete}
          data-testid={`button-toggle-${task.id}`}
          className={cn(
            "flex-shrink-0 w-6 h-6 border-2 rounded-full flex items-center justify-center mt-1 transition-all",
            isCompleted
              ? "bg-green-500 border-green-500"
              : isOverdue
              ? "border-red-400 hover:border-red-500"
              : "border-gray-300 hover:border-purple-500"
          )}
        >
          {isCompleted && (
            <motion.svg
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="w-4 h-4 text-white"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                clipRule="evenodd"
              />
            </motion.svg>
          )}
        </motion.button>

        {/* Task Content */}
        <div className="flex-1">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h4
                className={cn(
                  "font-semibold mb-1 transition-all",
                  isCompleted
                    ? "text-gray-500 line-through"
                    : isOverdue
                    ? "text-red-800"
                    : "text-gray-800"
                )}
                data-testid={`text-task-title-${task.id}`}
              >
                {task.title}
              </h4>
              
              {task.description && (
                <p
                  className={cn(
                    "text-sm mb-3 transition-all",
                    isCompleted
                      ? "text-gray-400 line-through"
                      : isOverdue
                      ? "text-red-600"
                      : "text-gray-600"
                  )}
                  data-testid={`text-task-description-${task.id}`}
                >
                  {task.description}
                </p>
              )}

              {/* Task Meta Info */}
              <div className="flex items-center space-x-4 text-sm">
                {dueDate && (
                  <div className={cn("flex items-center space-x-1", getDateColor())}>
                    {isOverdue ? (
                      <AlertTriangle className="h-4 w-4" />
                    ) : (
                      <Calendar className="h-4 w-4" />
                    )}
                    <span data-testid={`text-due-date-${task.id}`}>
                      {formatDueDate()}
                    </span>
                  </div>
                )}
                
                <div className="flex items-center space-x-1">
                  <div className={cn("w-2 h-2 rounded-full", getPriorityColor(task.priority))} />
                  <span
                    className={cn(
                      "capitalize",
                      isCompleted ? "text-gray-400" : "text-gray-500"
                    )}
                    data-testid={`text-priority-${task.id}`}
                  >
                    {task.priority} Priority
                  </span>
                </div>
              </div>
            </div>

            {/* Task Actions */}
            <div className="flex items-center space-x-2 ml-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={onEdit}
                data-testid={`button-edit-${task.id}`}
                className="p-2 text-gray-400 hover:text-purple-500 hover:bg-purple-50 rounded-lg"
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={onDelete}
                data-testid={`button-delete-${task.id}`}
                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
