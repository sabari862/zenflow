import { useState, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { RefreshCw } from "lucide-react";

interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  threshold?: number;
}

export function PullToRefresh({ onRefresh, children, threshold = 100 }: PullToRefreshProps) {
  const [isPulling, setIsPulling] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const startY = useRef(0);
  const currentY = useRef(0);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (window.scrollY === 0) {
      startY.current = e.touches[0].clientY;
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (window.scrollY > 0) return;

    currentY.current = e.touches[0].clientY;
    const distance = currentY.current - startY.current;

    if (distance > 0) {
      setPullDistance(Math.min(distance, threshold * 1.5));
      setIsPulling(distance > threshold);
      
      // Prevent default scrolling when pulling
      if (distance > 20) {
        e.preventDefault();
      }
    }
  }, [threshold]);

  const handleTouchEnd = useCallback(async () => {
    if (isPulling && !isRefreshing) {
      setIsRefreshing(true);
      try {
        await onRefresh();
      } catch (error) {
        console.error("Refresh failed:", error);
      }
      setTimeout(() => {
        setIsRefreshing(false);
      }, 1000);
    }
    
    setIsPulling(false);
    setPullDistance(0);
    startY.current = 0;
    currentY.current = 0;
  }, [isPulling, isRefreshing, onRefresh]);

  const opacity = Math.min(pullDistance / threshold, 1);
  const rotation = (pullDistance / threshold) * 180;

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className="h-full"
    >
      {/* Pull to Refresh Indicator */}
      <motion.div
        className="fixed top-0 left-0 right-0 z-30 flex items-center justify-center bg-white shadow-sm"
        style={{
          height: Math.min(pullDistance, threshold),
          opacity: opacity,
        }}
        data-testid="pull-to-refresh-indicator"
      >
        <div className="flex items-center space-x-2 text-purple-500">
          <motion.div
            animate={{
              rotate: isRefreshing ? 360 : rotation,
            }}
            transition={{
              duration: isRefreshing ? 1 : 0,
              repeat: isRefreshing ? Infinity : 0,
              ease: "linear",
            }}
          >
            <RefreshCw className="h-5 w-5" />
          </motion.div>
          <span className="text-sm font-medium">
            {isRefreshing ? "Refreshing..." : isPulling ? "Release to refresh" : "Pull to refresh"}
          </span>
        </div>
      </motion.div>

      {/* Content */}
      <motion.div
        style={{
          marginTop: Math.min(pullDistance, threshold),
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        {children}
      </motion.div>
    </div>
  );
}
