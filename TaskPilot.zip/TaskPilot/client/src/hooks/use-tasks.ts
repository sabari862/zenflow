import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Task, InsertTask, UpdateTask } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useTasks() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Get all tasks
  const {
    data: tasks,
    isLoading,
    error,
    refetch: refreshTasks,
  } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/tasks");
      return response.json();
    },
  });

  // Create task mutation
  const createTask = useMutation({
    mutationFn: async (taskData: Omit<InsertTask, "userId">) => {
      const response = await apiRequest("POST", "/api/tasks", taskData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      console.error("Failed to create task:", error);
    },
  });

  // Update task mutation
  const updateTask = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: UpdateTask }) => {
      const response = await apiRequest("PUT", `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      console.error("Failed to update task:", error);
    },
  });

  // Delete task mutation
  const deleteTask = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/tasks/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      console.error("Failed to delete task:", error);
    },
  });

  return {
    tasks,
    isLoading,
    error,
    createTask,
    updateTask,
    deleteTask,
    refreshTasks,
  };
}
