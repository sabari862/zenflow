import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { User } from "@shared/schema";

export function useAuth() {
  const queryClient = useQueryClient();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Get current user
  const {
    data: user,
    isLoading,
    error,
  } = useQuery<User>({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/auth/me");
      return response.json();
    },
    retry: false,
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async ({ provider, token }: { provider: string; token: string }) => {
      const response = await apiRequest("POST", `/api/auth/${provider}`, { token });
      return response.json();
    },
    onSuccess: (data) => {
      setIsAuthenticated(true);
      queryClient.setQueryData(["/api/auth/me"], data.user);
    },
    onError: (error) => {
      console.error("Login failed:", error);
      setIsAuthenticated(false);
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/auth/logout");
      return response.json();
    },
    onSuccess: () => {
      setIsAuthenticated(false);
      queryClient.clear();
    },
  });

  // Update authentication status based on user data
  useEffect(() => {
    setIsAuthenticated(!!user && !error);
  }, [user, error]);

  const login = async (provider: string, token: string) => {
    return loginMutation.mutateAsync({ provider, token });
  };

  const logout = async () => {
    return logoutMutation.mutateAsync();
  };

  return {
    user,
    isAuthenticated,
    isLoading,
    login,
    logout,
    loginMutation,
    logoutMutation,
  };
}
